package com.example.retrofit1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adapter(): RecyclerView.Adapter<Adapter.ViewHolder>() {

    var items: ArrayList<String> = arrayListOf()
        set(value){
            field = value
        }

    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        var tv: TextView
        init {
            tv = itemView.findViewById<TextView>(R.id.textView)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = items[position]
        holder.tv.text = currentItem
    }

    override fun getItemCount(): Int {
        return items.size
    }
}