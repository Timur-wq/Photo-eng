package com.example.retrofit1

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetroInstance {
    fun getRetroInstance(): Retrofit{
        return Retrofit.Builder()
            .baseUrl("https://httpbin.org/ip/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
}